import userModel from "../models/userModel.js";
import jwt from "jsonwebtoken";
import bcrypt from "bcrypt";
import validator from "validator";
import otpGenerator from "otp-generator";
import nodemailer from "nodemailer";

// In-memory OTP store (use Redis for production)
const otpStore = new Map();

// Email transporter configuration
const transporter = nodemailer.createTransport({
    service: "gmail", // You can use other email services
    auth: {
        user: process.env.EMAIL_USER, // Your email address
        pass: process.env.EMAIL_PASS, // Your email password or app-specific password
    },
});

// Function to send OTP via email
const sendOtpEmail = async (email, otp) => {
    try {
        const mailOptions = {
            from: process.env.EMAIL_USER,
            to: email,
            subject: "Your OTP Code",
            text: `Your OTP code is: ${otp}`,
        };

        await transporter.sendMail(mailOptions);
        console.log(`OTP sent to ${email}`);
    } catch (error) {
        console.error("Error sending OTP email:", error);
        throw new Error("Failed to send OTP email");
    }
};

// Function to generate OTP
const generateOtp = () => {
    return otpGenerator.generate(6, { upperCaseAlphabets: false, specialChars: false });
};

// Login User
const loginUser = async (req, res) => {
    const { email, password, otp } = req.body;
    try {
        const user = await userModel.findOne({ email });
        if (!user) {
            return res.json({ success: false, message: "User doesn't exist" });
        }

        const isMatch = await bcrypt.compare(password, user.password);

        if (!isMatch) {
            return res.json({ success: false, message: "Invalid credentials" });
        }

        // Verify OTP
        if (!otp) {
            // Send OTP if not provided
            const generatedOtp = generateOtp();
            otpStore.set(email, generatedOtp);

            // Send OTP via email
            await sendOtpEmail(email, generatedOtp);

            return res.json({ success: true, message: "OTP sent to your email" });
        }

        const storedOtp = otpStore.get(email);
        if (storedOtp !== otp) {
            return res.json({ success: false, message: "Invalid OTP" });
        }

        // Clear OTP after verification
        otpStore.delete(email);

        const token = createToken(user._id);
        res.json({ success: true, token });
    } catch (error) {
        console.log(error);
        res.json({ success: false, message: "Error" });
    }
};

const createToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET);
};

// Register User
const registerUser = async (req, res) => {
    const { name, password, email, otp } = req.body;
    try {
        // Check if user already exists
        const exist = await userModel.findOne({ email });
        if (exist) {
            return res.json({ success: false, message: "User already exists" });
        }

        // Validate email format and strong password
        if (!validator.isEmail(email)) {
            return res.json({ success: false, message: "Please enter a valid email" });
        }

        if (password.length < 8) {
            return res.json({ success: false, message: "Please enter a strong password" });
        }

        // Verify OTP
        if (!otp) {
            // Send OTP if not provided
            const generatedOtp = generateOtp();
            otpStore.set(email, generatedOtp);

            // Send OTP via email
            await sendOtpEmail(email, generatedOtp);

            return res.json({ success: true, message: "OTP sent to your email" });
        }

        const storedOtp = otpStore.get(email);
        if (storedOtp !== otp) {
            return res.json({ success: false, message: "Invalid OTP" });
        }

        // Clear OTP after verification
        otpStore.delete(email);

        // Hashing user password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        const newUser = new userModel({
            name: name,
            email: email,
            password: hashedPassword,
        });

        const user = await newUser.save();
        const token = createToken(user._id);
        res.json({ success: true, token });
    } catch (error) {
        console.log(error);
        res.json({ success: false, message: "This is an error" });
    }
};

export { loginUser, registerUser };

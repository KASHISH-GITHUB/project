import "./LoginPopup.css";
import { assets } from "../../assets/assets";

import axios from "axios";
import React, { useContext, useState } from "react";
import { StoreContext } from "../../context/StoreContext";

const LoginPopup = ({ setShowLogin }) => {
  const { url, setToken } = useContext(StoreContext);

  const [currState, setCurrState] = useState("Login"); // "Login", "Sign Up", or "Verify OTP"
  const [data, setData] = useState({
    name: "",
    email: "",
    password: "",
    otp: "",
  });

  const [isOtpSent, setIsOtpSent] = useState(false);

  const onChangeHandler = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    setData((data) => ({ ...data, [name]: value }));
  };

  const sendOtp = async () => {
    const endpoint = currState === "Login" ? "/api/user/login" : "/api/user/register";
    try {
      const response = await axios.post(`${url}${endpoint}`, {
        email: data.email,
        password: data.password,
        name: data.name,
      });

      if (response.data.success) {
        setIsOtpSent(true);
        alert("OTP sent to your email!");
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error(error);
      alert("Error sending OTP. Please try again.");
    }
  };

  const verifyOtp = async () => {
    const endpoint = currState === "Login" ? "/api/user/login" : "/api/user/register";
    try {
      const response = await axios.post(`${url}${endpoint}`, {
        email: data.email,
        password: data.password,
        otp: data.otp,
        name: data.name,
      });

      if (response.data.success) {
        setToken(response.data.token);
        localStorage.setItem("token", response.data.token);
        setShowLogin(false);
      } else {
        alert(response.data.message);
      }
    } catch (error) {
      console.error(error);
      alert("Error verifying OTP. Please try again.");
    }
  };

  const onSubmitHandler = (event) => {
    event.preventDefault();

    if (isOtpSent) {
      verifyOtp();
    } else {
      sendOtp();
    }
  };

  return (
    <div className="login-popup">
      <form onSubmit={onSubmitHandler} className="login-popup-container">
        <div className="login-popup-title">
          <h2>{currState}</h2>
          <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="" />
        </div>
        <div className="login-popup-inputs">
          {currState === "Sign Up" && (
            <input
              name="name"
              onChange={onChangeHandler}
              value={data.name}
              type="text"
              placeholder="Your name"
              required={!isOtpSent}
              disabled={isOtpSent}
            />
          )}
          <input
            name="email"
            onChange={onChangeHandler}
            value={data.email}
            type="email"
            placeholder="Your email"
            required
            disabled={isOtpSent}
          />
          <input
            name="password"
            onChange={onChangeHandler}
            value={data.password}
            type="password"
            placeholder="Password"
            required={!isOtpSent}
            disabled={isOtpSent}
          />
          {isOtpSent && (
            <input
              name="otp"
              onChange={onChangeHandler}
              value={data.otp}
              type="text"
              placeholder="Enter OTP"
              required
            />
          )}
        </div>
        <button type="submit">{isOtpSent ? "Verify OTP" : currState === "Sign Up" ? "Send OTP" : "Login with OTP"}</button>
        <div className="login-popup-condition">
          <input type="checkbox" required />
          <p>By Continuing, I agree to the terms of use & privacy policy.</p>
          {currState === "Login" ? (
            <p>
              Create a new account? <span onClick={() => setCurrState("Sign Up")}>Click here</span>
            </p>
          ) : (
            <p>
              Already have an account? <span onClick={() => setCurrState("Login")}>Login here</span>
            </p>
          )}
        </div>
      </form>
    </div>
  );
};

export default LoginPopup;
